class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  
  
  # Check if this header should be rendered highlighted.
  def is_clicked(hname)
    # If this header name is included in the sessions sort params, make the background yellow.
    if session[:s_params].include? hname
      return 'hilite'
    # Otherwise, do nothing.
    else
      return nil
    end
  end
end
